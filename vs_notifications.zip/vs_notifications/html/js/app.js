const stack = document.getElementById('stack');
const pool = [];
const active = [];
const positions = {
    top: 'top',
    'top-left': 'top-left',
    'top-right': 'top-right',
    bottom: 'bottom',
    'bottom-left': 'bottom-left',
    'bottom-right': 'bottom-right',
};
let placed = 'top';
let cap = 5;
let seq = 0;

function place(name) {
    const next = positions[String(name || '').toLowerCase()] || 'top';
    if (next === placed) return;
    stack.classList.remove(placed);
    stack.classList.add(next);
    placed = next;
}

function create() {
    const node = document.createElement('div');
    node.className = 'banner';
    node.hidden = true;
    node.innerHTML = '<strong></strong><span></span><button class="x" type="button" aria-label="Dismiss">\u00d7</button>';
    node._label = node.firstChild;
    node._text = node.children[1];
    stack.appendChild(node);
    return node;
}

function ensure(count) {
    const size = Math.max(1, Math.min(8, count));
    while (pool.length + active.length < size) pool.push(create());
    cap = size;
}

function release(node) {
    if (!node || node.hidden) return;
    clearTimeout(node._life);
    clearTimeout(node._hide);
    node._token = (node._token || 0) + 1;
    node.hidden = true;
    node.classList.remove('in', 'out');
    const index = active.indexOf(node);
    if (index !== -1) active.splice(index, 1);
    pool.push(node);
}

function dismiss(node) {
    if (!node || node.hidden || node.classList.contains('out')) return;
    clearTimeout(node._life);
    const token = (node._token || 0) + 1;
    node._token = token;
    node.classList.remove('in');
    node.classList.add('out');
    node._hide = setTimeout(() => {
        if (node._token === token) release(node);
    }, 170);
}

function show(data) {
    if (data.position) place(data.position);

    const max = Math.max(1, Math.min(8, Number(data.max) || cap));
    if (max !== cap) ensure(max);

    const id = data.id ? String(data.id) : '';
    let node = id ? active.find((item) => item.dataset.id === id && !item.hidden) : null;

    if (!node) {
        if (!pool.length) release(active[0]);
        node = pool.pop();
        if (!node) return;
        active.push(node);
        node.dataset.id = id || `n${seq += 1}`;
        node.hidden = false;
        node.classList.remove('out');
        node.classList.remove('in');
        stack.appendChild(node);
        void node.offsetWidth;
        node.classList.add('in');
    } else if (node.classList.contains('out')) {
        node._token = (node._token || 0) + 1;
        clearTimeout(node._hide);
        node.classList.remove('out');
    }

    node._label.textContent = data.label || 'Info';
    node._text.textContent = data.message || '';
    node.style.setProperty('--c', data.color || '#e7c04a');

    while (active.length > cap) release(active[0]);

    clearTimeout(node._life);
    const duration = Math.max(800, Number(data.duration) || 4500);
    node._life = setTimeout(() => dismiss(node), duration);
}

stack.addEventListener('click', (event) => {
    const button = event.target.closest('.x');
    if (button) dismiss(button.parentNode);
});

stack.addEventListener('animationend', (event) => {
    const node = event.target;
    if (event.animationName === 'out' && node.classList.contains('out')) release(node);
});

window.addEventListener('message', (event) => {
    const data = event.data;
    if (!data || data.action !== 'notify') return;
    show(data);
});

ensure(5);

if (typeof GetParentResourceName !== 'function') {
    document.body.classList.add('preview');
    const position = new URLSearchParams(location.search).get('position') || 'top';
    show({ label: 'Success', color: '#4dcc6a', message: 'Lock picked', duration: 600000, max: 5, position });
    show({ label: 'Error', color: '#ef5b5b', message: 'Door is bolted from the inside', duration: 600000, max: 5, position });
    show({ label: 'Info', color: '#e7c04a', message: 'Radio channel 4', duration: 600000, max: 5, position });
}
