local function notify(src, message, nType, duration)
    src = tonumber(src)
    if not src or src <= 0 then return end
    TriggerClientEvent('vs_notifications:notify', src, message, nType, duration)
end

exports('Notify', notify)
