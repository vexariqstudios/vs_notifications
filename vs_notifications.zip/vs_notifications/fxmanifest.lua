fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'vs_notifications'
author 'Vexariq Studios'
description 'Lightweight banner notifications, optimized for smooth performance'
version '1.0.0'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/css/*.css',
    'html/js/*.js',
}

client_scripts {
    'config/config.lua',
    'client/main.lua',
}

server_scripts {
    'server/main.lua',
}
