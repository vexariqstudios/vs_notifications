local positions = {
    top = true,
    ['top-left'] = true,
    ['top-right'] = true,
    bottom = true,
    ['bottom-left'] = true,
    ['bottom-right'] = true,
}

local function spot()
    local value = Config.Position
    if type(value) == 'string' then
        value = value:lower()
        if positions[value] then return value end
    end
    return 'top'
end

local function resolve(message, nType, duration)
    local data = message
    if type(message) ~= 'table' then
        data = {
            message = message,
            type = nType,
            duration = duration,
        }
    end

    local kind = tostring(data.type or data.nType or 'inform'):lower()
    local style = Config.Types[kind] or Config.Types.inform
    local text = data.description or data.message or data.text or ''
    if text == '' then
        text = data.title or ''
    end

    local time = tonumber(data.duration or data.time) or Config.Duration
    if time < 800 then time = 800 end

    return {
        id = data.id,
        message = tostring(text),
        label = style.label,
        color = style.color,
        duration = time,
        max = Config.Max or 5,
    }
end

local lastKey
local lastAt = 0

local function notify(message, nType, duration)
    local payload = resolve(message, nType, duration)
    if payload.message == '' then return end

    local now = GetGameTimer()
    local key = payload.label .. '\0' .. payload.message
    local window = Config.DuplicateWindow or 300
    if not payload.id and key == lastKey and (now - lastAt) < window then
        return
    end
    lastKey = key
    lastAt = now

    if #payload.message > 180 then
        payload.message = payload.message:sub(1, 177) .. '...'
    end

    SendNUIMessage({
        action = 'notify',
        id = payload.id,
        message = payload.message,
        label = payload.label,
        color = payload.color,
        duration = payload.duration,
        max = payload.max,
        position = spot(),
    })
end

exports('Notify', notify)

RegisterNetEvent('vs_notifications:notify', function(message, nType, duration)
    notify(message, nType, duration)
end)
