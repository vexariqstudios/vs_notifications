Config = {}

Config.Duration = 4500
Config.Max = 5


Config.Position = 'top'


Config.DuplicateWindow = 300


Config.Types = {
    success = { label = 'Success', color = '#4dcc6a' },
    error = { label = 'Error', color = '#ef5b5b' },
    warning = { label = 'Warning', color = '#e7a23a' },
    inform = { label = 'Info', color = '#e7c04a' },
    info = { label = 'Info', color = '#e7c04a' },
    primary = { label = 'Info', color = '#e7c04a' },
}
